package assignment5;

import java.util.Scanner;

public class PhoneBookApp{
	
	private PhoneBook phoneBook;
	public PhoneBookApp(String fileName) {
		phoneBook = new PhoneBook(fileName);
	}

	public void displayMenu() {
		
		System.out.println("***MY PHONEBOOK APPLICATION***");
		String userInput;
		
		while (true) {
			System.out.println("Please choose an operation:");
			System.out.print("A (Add) | S (Search) | P (Print) |R (Remove) | Q (Quit):");
			
			Scanner sc = new Scanner(System.in);
			userInput = sc.next();
			
			if (userInput.equals("A")) {
				add(phoneBook);
			} else if (userInput.equals("S")) {
				search(phoneBook);
			}
			else if (userInput.equals("P")) {
				print(phoneBook);
			} else if (userInput.equals("R")) {
				remove(phoneBook);
			} 
			else if (userInput.equals("Q")) {
				System.out.println("Thank You");
				break;
			}
			System.out.println();
		   
		}
	
	}
	
	void add(PhoneBook phoneBook) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter name:");
		String name = sc.nextLine();
		System.out.print("Enter phone number:");
		String phone = sc.nextLine();

		Contact newContact = new Contact(name, phone);
		
		phoneBook.add(newContact);
	}

	
	  public void search(PhoneBook phoneBook) {
		  Scanner sc = new Scanner(System.in); 
		  System.out.print("Enter name:"); 
		  String name = sc.nextLine();
	  
		  String phone = phoneBook.search(name);
	  
	  if(phone != null) 
		  System.out.println("Phone: " + phone); 
	  else
		  System.out.println("Not found!"); }
	 

	public void remove(PhoneBook phoneBook) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter name:");
		String name = sc.nextLine();
		String phone = phoneBook.search(name);
		  
		if(phone != null) {
			System.out.println("Found"); 
		  	System.out.println(name);
		}
		else
			System.out.println("Not found!");
		

		phoneBook.remove(name);
		
	}
	
	public void print(PhoneBook phoneBook) {
		phoneBook.print();
	}

}
