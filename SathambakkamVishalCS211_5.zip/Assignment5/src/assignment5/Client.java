package assignment5;

public class Client {
	
	public static void main(String[] args) {
		PhoneBookApp app = new PhoneBookApp("phonebook.txt");
		app.displayMenu();
		
	}

}


