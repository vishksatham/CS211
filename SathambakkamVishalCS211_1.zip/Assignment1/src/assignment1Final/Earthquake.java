package assignment1Final;

public class Earthquake {
	
	private String date;
	private double depth;
	private double magnitude;
	private String address;
	private String state;
	
	//Create a constructor
	public Earthquake(String date, double depth, double magnitude, String address, String state) {
		super();
		this.date = date;
		this.depth = depth;
		this.magnitude = magnitude;
		this.address = address;
		this.state = state;
	}
	
	//Getter method for date
	public String getDate() {
		return date;
	}
	
	//Setter method for date
	public void setDate(String date) {
		this.date = date;
	}
	
	//Getter method for depth
	public double getDepth() {
		return depth;
	}
	
	//Setter method for depth
	public void setDepth(double depth) { 
		this.depth = depth;
	}
	
	//Getter method for magnitude
	public double getMagnitude() {
		return magnitude;
	}
	
	//Setter method for magnitude
	public void setMagnitude(double magnitude) {
		this.magnitude = magnitude;
	}
	
	//Getter method for address
	public String getAddress() {
		return address;
	}
	
	//Setter method for address
	public void setAddress(String address) {
		this.address = address;
	}
	
	//Getter method for state
	public String getState() {
		return state;
	}
	
	//Setter method for state
	public void setState(String state) {
		this.state = state;
	}

}

