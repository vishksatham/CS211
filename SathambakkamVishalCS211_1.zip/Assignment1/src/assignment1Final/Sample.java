package assignment1Final;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/*Description: Program reads earthquake data from a csv file into a dynamic 
 * arrayList and prompts user regarding magnitude data based off of their 
 * specifications. Furthermore, magnitude search results are saved in a 
 * text file using user state information 
*/
public class Sample {
	
	static String inputDate;
	static String inputMagnitude;
	static String inputState;

	public static void main(String[] args) throws IOException, ParseException {

		System.out.println("===============Earthquake Search Application==================");
		//Create an object Earthquake and assign the property values
		//Declare and Save to ArrayList
		ArrayList<String[]> arraylist = new ArrayList<String[]>();
		//Read data from csv file using buffered reader
		BufferedReader buffer = new BufferedReader(new FileReader("earthquake.csv"));
		String lines = buffer.readLine();
		boolean firstLine = true;
		while (lines != null) {
			if (!firstLine) {
				//Save data to ArrayList
				String csvDate = "";
				String csvMagnitude = "";
				String csvState = "";
				String[] splitarray = lines.split(",");
				for (int i = 0; i < splitarray.length; i++) {
					switch (i) {
					case 0:
						csvDate = splitarray[i];
						break;
					case 1:
						csvMagnitude = splitarray[i];
						break;
					default:
						csvState = splitarray[i].replace("\"", "");
						break;
					}
				}
				String s[] = new String[3];
				s[0] = csvDate;
				s[1] = csvMagnitude;
				s[2] = csvState;
				arraylist.add(s);
			}
			firstLine = false;
			lines = buffer.readLine();
		}
		
		String decision = "yes";
		Scanner scan = new Scanner(System.in);
		try {

			while (decision.equals("yes")) {
				//Scan input from user

				System.out.println("==============================================================");
				System.out.print("Date [yyyy-mm-dd] [from]:");
				String date1 = scan.nextLine();
				System.out.print("Date [yyyy-mm-dd] [to]:");
				String date2 = scan.nextLine();
				System.out.print("State:");
				String userstate = scan.nextLine();
				System.out.print("Magnitude [min]:");
				String usermagnitude = scan.nextLine();

				lines = buffer.readLine();
				// Validate the input
				dataComparison(date1, date2, usermagnitude, userstate, arraylist);

				//Call method dataComparison to arraylist data with user input
				System.out.print("Do you want to continue? (yes/no): ");
				decision = scan.nextLine();

				if (decision.equals("no")) {
					System.out.println("Thanks");
					System.out.println("Be Earthquake Prepared");
				}
			}
		} 
		
		catch (Exception e) {
		}

		buffer.close();
		scan.close();

	}

	public static void dataComparison(String date1, String date2, String magnitude, String userstate,
			ArrayList<String[]> arraylist) throws ParseException, IOException {

		// Loop through the ArrayList and verify the data
		try {
			int resultCount = 0;
			double magnitudeFromParm = Double.parseDouble(magnitude);
			int magnitudeInInteger = (int) magnitudeFromParm;
			double magnitudeToCheck1 = new Double(magnitudeInInteger);
			double magnitudeToCheck2 = new Double(magnitudeInInteger);
			boolean exactFlag = true;
			if (Double.compare(magnitudeFromParm, magnitudeToCheck1) == 0) {
				magnitudeInInteger++;
				magnitudeToCheck2 = new Double(magnitudeInInteger);
				exactFlag = false;

			} 
			
			for (int i = 0; i < arraylist.size(); i++) {
				String s[] = arraylist.get(i);
				Date fromDate = new SimpleDateFormat("yyyy-MM-dd").parse(date1);
				Date toDate = new SimpleDateFormat("yyyy-MM-dd").parse(date2);
				double magnitudeFromArray = Double.parseDouble(s[1]);
				Date arrayDate = new SimpleDateFormat("yyyy-MM-dd").parse(s[0]);
				
				if ((exactFlag && Double.compare(magnitudeFromArray, magnitudeFromParm) == 0)
						|| (!exactFlag && Double.compare(magnitudeFromArray, magnitudeToCheck1) >= 0)
								&& (!exactFlag && Double.compare(magnitudeFromArray, magnitudeToCheck2) <= 0)) {
				}

				if (userstate.trim().toUpperCase().equals(s[2].trim().toUpperCase())) {
					if (arrayDate.after(fromDate) && arrayDate.before(toDate)) {
						if ((exactFlag && Double.compare(magnitudeFromArray, magnitudeFromParm) == 0)
								|| (!exactFlag && Double.compare(magnitudeFromArray, magnitudeToCheck1) >= 0)
										&& (!exactFlag && Double.compare(magnitudeFromArray, magnitudeToCheck2) <= 0)) {
							System.out.println(s[0].trim() + ">>Magnitude:" + s[1]);
							resultCount++;
						}
					}
				}
			}
			if (resultCount > 0) {
				System.out.println("--------------------------");
				System.out.println("Results found:" + Integer.toString(resultCount));
			} else {
				System.out.println("No-file is created, because there is no" + "\n" + "result found");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void dateComparison(String date1, String date2, ArrayList<Earthquake> arraylist, String usermagnitude,
			String state) throws ParseException, IOException {

		//Create a new dynamic arraylist
		ArrayList<String> outputarraylist = new ArrayList<String>();

		//Convert the date
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		Date d1 = sf.parse(date1);
		Date d2 = sf.parse(date2);

		for (int i = 0; i < arraylist.size(); i++) {
			Date EarthquakeDate = sf.parse(arraylist.get(i).getDate());

			//Compare user input data, magnitude, and state with csv arraylist data
			if (EarthquakeDate.after(d1) && EarthquakeDate.after(d2)) {
				if (Double.parseDouble(usermagnitude) <= arraylist.get(i).getMagnitude()
						&& (state.equals(arraylist.get(i).getState()))) {
					System.out.println(arraylist.get(i).getDate() + ">>" + arraylist.get(i).getMagnitude());

					//add the search output data to the new arraylist
					outputarraylist.add(arraylist.get(i).getDate() + ">>" + arraylist.get(i).getMagnitude());

				}
			}
		}

		if (outputarraylist.size() >= 1) {
			System.out.println("--------------------------------------------------------------------");
			System.out.println("Results found :" + outputarraylist.size());

		}

		else {
			System.out.println("No results found");
		}

		//write the output into the file
		FileWriter writer = new FileWriter("Earthquake_" + state + ".txt");
		for (String str : outputarraylist) {
			writer.write(str + System.lineSeparator());
		}

		writer.close();
	}

}