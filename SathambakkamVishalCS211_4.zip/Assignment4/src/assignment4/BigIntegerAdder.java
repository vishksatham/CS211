package assignment4;

import java.util.Scanner;

/* Authors: Max Carver & Vishal Sathambakkam
 * Date: 6/10/22
 * Description: This class receives two large integer inputs from the user, 
 * pushes them into two LinkedStacks, and then adds the two integers together. 
 * The LIFO concept is utilized to do this aforementioned functionality.
 */

public class BigIntegerAdder {

	// Adds together the two referenced input LinkedStack<int>,
	// assuming least significant digit on top, and
	// returns their sum as a string
	private static String add(LinkedStack s1, LinkedStack s2) {
		String result = "";
		int sum = 0;
		int carry = 0;

		// adds digits in both stack until at least one of them is empty
		while (!s1.isEmpty() && !s2.isEmpty()) {
			int n1 = s1.pop();
			int n2 = s2.pop();
			sum = n1 + n2 + carry;
			carry = sum / 10;
			int rem = sum % 10;
			result = rem + result;
		}

		// appends leftover in first number (s1) if any
		while (!s1.isEmpty()) {
			sum = s1.pop() + carry;
			carry = sum / 10;
			int rem = sum % 10;
			result = rem + result;
		}

		// appends leftover in second number (s2) if any
		while (!s2.isEmpty()) {
			sum = s2.pop() + carry;
			carry = sum / 10;
			int rem = sum % 10;
			result = rem + result;
		}

		// appends last carry if there is one
		if (carry == 1) {
			result = carry + result;
		}

		return result;
	}

	// Asks the user to enter a very large positive integer
	// reads the input as a string
	// stores the digits in the string into the input parameter
	// LinkedStack, s.
	// The right most digit stays on top of stack
	// Example:
	// Number: �1234567890�
	// s contains digits from top to bottom: 0-9-8-7-6-5-4-3-2-1
	public static void readNumber(LinkedStack s) {
		String numberInput;
		Scanner userInput = new Scanner(System.in);
		System.out.println("Enter a very large positive number:");
		numberInput = userInput.next();

		// Push all the digits of string back onto linked stack
		for (int i = 0; i < numberInput.length(); i++) {
			s.push(numberInput.charAt(i) - '0');
		}
	}

	// Reads two large numbers as strings
	// Stores digits in strings into stack
	// s1 stores the digits in the first large number
	// s2 stores the digits in the second large number
	// Adds two large numbers starting with the right most digits
	// Prints the sum to the console
	public static void main(String[] args) {
		LinkedStack s1 = new LinkedStack();
		LinkedStack s2 = new LinkedStack();
		readNumber(s1);
		readNumber(s2);
		String result = add(s1, s2);
		System.out.println("Sum=" + result);
	}
}
