package assignment4;

/* Authors: Max Carver & Vishal Sathambakkam
 * Date: 6/10/22
 * Description: This class implements a Stack data structure using LinkedLists
 * and furthermore implements the declared methods within StackInterface.
 */

public class LinkedStack implements StackInterface {

	// Node at the top of the stack
	Node topNode;

	LinkedStack() {
		this.topNode = null;
	}

	// Implementing the top method declared in StackInterface
	// returns the top element of the LinkedStack, prints message if LinkedStack is
	// empty
	@Override
	public int top() {
		// If the stack is not empty, return the data of the top node
		if (!isEmpty()) {
			return topNode.data;
		}
		// Otherwise, display an empty stack message
		else {
			System.out.println("The stack is empty");
			return -1;
		}
	}

	// Implementing the pop method declared in StackInterface
	// removes the top element of the LinkedStack, prints 
	// message if LinkedStack is empty
	@Override
	public int pop() {

		// Remove the top node by making it equal to the previous node
		if (!isEmpty()) {
			int data = topNode.data;
			topNode = topNode.previousNode;
			return data;
		}

		else {
			System.out.println("The stack is empty");
			return -1;
		}
	}

	// Implementing the push method declared in StackInterface
	// adds new element to top of LinkedStack
	@Override
	public void push(int digit) {
		Node newNode = new Node(digit);
		// Validate whether or not the stack is null
		// if null, then the node that is created above
		// will be assigned to top as the first node.
		if (topNode == null) {
			topNode = newNode;
		}

		// Otherwise, move the top variable to the next node
		else {
			newNode.previousNode = topNode;
			topNode = newNode;
		}
	}

	// Implementing the isEmpty method from StackInterface to
	// check if there is no value in the top element of the stack
	@Override
	public boolean isEmpty() {
		return topNode == null;
	}

	// Create an encapsulated subclass/inner class to initialize a node object
	private class Node {
		Node previousNode;
		int data;

		Node(int data) {
			this.data = data;
			this.previousNode = null;
		}
	}
}
