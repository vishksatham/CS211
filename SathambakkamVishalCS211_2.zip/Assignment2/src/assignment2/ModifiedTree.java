package assignment2;

import java.awt.Color;

/*
 * Author: Vishal Sathambakkam
 * Date: 5/14/22
 * Description: This class modifies the original 
 * Tree.java class given in the starter .zip file.
 * This program produces a recursive tree pattern 
 * in which the thickness of the branches are proportional 
 * to the branch ratio, and furthermore changes color
 * to green at a certain level (when the variable "n" equals 8)
 */

public class ModifiedTree {
	public static void tree(int n, double x, double y, double a, double branchRadius) {
		
		double bendAngle   = Math.toRadians(50);
        double branchAngle = Math.toRadians(20);
        double branchRatio = 0.65;
		
		double cx = x + Math.cos(a) * branchRadius;
        double cy = y + Math.sin(a) * branchRadius;
        StdDraw.setPenRadius(0.05 * Math.pow(branchRadius, 1.2));
        
        if(n>3) {
        	StdDraw.setPenColor(43, 29, 20); //Brown
        }
        else if(n==2) {
        	StdDraw.setPenColor(178, 194, 72); //Light Green
        }
        else {
        	StdDraw.setPenColor(52, 124, 44); //Dark Green
        }
        StdDraw.line(x, y, cx, cy);
        if (n == 0) return;
        
        tree(n-1, cx, cy, (a + bendAngle - branchAngle), branchRadius * branchRatio);
        tree(n-1, cx, cy, (a + bendAngle - (branchAngle*2)), branchRadius * branchRatio);
        tree(n-1, cx, cy, (a + bendAngle - (branchAngle*5)), branchRadius * branchRatio);
        tree(n-1, cx, cy, (a + bendAngle - (branchAngle*3)), branchRadius * branchRatio);
        tree(n-1, cx, cy, (a + bendAngle - (branchAngle*4)), branchRadius * branchRatio);
        
      
	}

	public static void main(String[] args) {
		
		int n = 8;
		StdDraw.enableDoubleBuffering();
		tree(n, 0.5, 0, Math.PI/2, 0.3);
        StdDraw.show();
		

	}

}
