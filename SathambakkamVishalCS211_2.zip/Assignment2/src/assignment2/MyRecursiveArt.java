package assignment2;

import java.awt.Color;

/*
 *Author: Vishal Sathambakkam
 *Date: 5/14/22
 *Description: The MyRecursiveArt class produces a 
 *recursive pattern drawing of my own design. In 
 *utilizing recursive functions, my implementation
 * allows for a variable "n" to control the depth 
 * of recursion within the program
 */

public class MyRecursiveArt {
	public static void pattern(int n, double x, double y, double a, double branchRadius, int iterator) {
		
		double branchRatio = 0.1;
		
		double cx = x + Math.cos(a) * branchRadius;
        double cy = y + Math.sin(a) * branchRadius;
        StdDraw.setPenRadius(0.05 * Math.pow(0.8, iterator));
        StdDraw.setPenColor(Color.GREEN);
        
        StdDraw.line(x, y, cx, cy);
        if (n == 0) return;
        
        iterator++;
        for(int z = 0; z < 4; z++) {
        	pattern(n-1, cx, cy, z*Math.toRadians(90), 4*(branchRadius * branchRatio), iterator);
        }
        
      
	}
	
	public static void pattern(int n, double x, double y, double branchRadius) {
		for(int z = 0; z < 4; z++) {
			pattern(n, x, y, z*Math.toRadians(90), branchRadius, 12);
		}
	}
	
	
	public static void main(String[] args) {
		
		int n = 8;
		StdDraw.enableDoubleBuffering();
		pattern(n, 0.5, 0.5, 0.3);
        StdDraw.show();
		
	}

}

