package assignment2;

import java.awt.Color;
import java.util.Random;

/*
 *Author: Vishal Sathambakkam
 *Date: 5/14/22
 *Description: This class modifies the original Tree.java
 *class and adds randomization to the recursive implementation 
 *by using the random class and other static math functions. 
 *Randomness is seen through the tree's branch angle, branch 
 *radius(length) and color
 */
public class RandomizedRecursiveTree {
	
	public static void tree(int n, double x, double y, double a, double branchRadius, Color color, int iterator) {
		
		Random rand = new Random();

		double bendAngle = Math.toRadians(15); 
		double branchAngle = Math.toRadians(37);
		double branchRatio = 0.65 * rand.nextDouble()+0.3;

		double cx = x + Math.cos(a) * branchRadius;
		double cy = y + Math.sin(a) * branchRadius;
		StdDraw.setPenRadius(0.05 * Math.pow(0.6, iterator));
		StdDraw.setPenColor(color);

		StdDraw.line(x, y, cx, cy);
		if (n == 0)
			return;

		iterator++;
		
		tree(n - 1, cx, cy, a + bendAngle - branchAngle * rand.nextDouble(), branchRadius * branchRatio, color, iterator);
		tree(n - 1, cx, cy, a + bendAngle - 2*branchAngle * rand.nextDouble(), branchRadius * branchRatio, color, iterator);
		tree(n - 1, cx, cy, a + bendAngle + branchAngle * rand.nextDouble(), branchRadius * branchRatio, color, iterator);
		tree(n - 1, cx, cy, a + bendAngle - branchAngle * rand.nextDouble(), branchRadius * branchRatio, color, iterator);
		tree(n - 1, cx, cy, a + bendAngle + branchAngle * rand.nextDouble(), branchRadius * branchRatio, color, iterator);
		
		
	}

	public static void main(String[] args) {
		
		Random rand = new Random();
		Color color = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));

		int n = 8;
		StdDraw.enableDoubleBuffering();
		tree(n, 0.5, 0, Math.PI / 2, 0.3, color, 2);
		StdDraw.show();

	}
}
