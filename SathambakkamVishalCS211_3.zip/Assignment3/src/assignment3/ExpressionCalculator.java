package assignment3;

import java.util.Scanner;
import java.util.Stack;

/* Author: Vishal Sathambakkam
 * Date: 5/27/22
 * Description: This expression calculator class utilizes 
 * the stack data structure and allows a user to input a 
 * line of operands and operators, in addition to various
 * symbols such as "<<", "^" and "\". If there are not 
 * enough operands to perform the given operations, the 
 * program will prompt an error message but continue to 
 * perform. This program will continue to loop through 
 * unless the user states that they would not like to 
 * continue to calculate any more.
 */

public class ExpressionCalculator {

	public static void main(String[] args) {

		// Utilize the built-in Stack class to initialize a stack to store the operands
		Stack<Integer> numStack = new Stack<Integer>();
		String again;
		int result = 0;

		// Create an object of the scanner class to read inputs from the user
		Scanner sc = new Scanner(System.in);

		do {

			System.out.println("Enter the expression: ");

			// Read line from the user
			String userInput = sc.nextLine();

			// split the string for every space occurred and store in an array of the string type
			String[] elements = userInput.split(" ");
			
			for (String element : elements) {

				// Pass the regular expression for numbers to validate whether the String is a number or not
				// Returns true if the aforementioned string only contains digits
				if (element.matches("[0-9]+")) {
					numStack.push(Integer.parseInt(element));
				}

				// Pass conditional statements for integer operators (+, -, *, /, %)
				else if (element.equals("+")) {
					if (numStack.size() < 2) {
						System.out.println("Missing operands");
					} else {
						int num1 = numStack.pop();
						int num2 = numStack.pop();
						numStack.push(num1 + num2);
					}
				} else if (element.equals("-")) {
					if (numStack.size() < 2) {
						System.out.println("Missing operands");
					} else {
						int num1 = numStack.pop();
						int num2 = numStack.pop();
						numStack.push(num1 - num2);
					}
				}

				else if (element.equals("*")) {
					if (numStack.size() < 2) {
						System.out.println("Missing operands");
					} else {
						int num1 = numStack.pop();
						int num2 = numStack.pop();
						numStack.push(num1 * num2);
					}
				} else if (element.equals("/")) {
					if (numStack.size() < 2) {
						System.out.println("Missing operands");
					} else {
						// Utilize a try-catch block to handle the division by 0 exception
						try {
						int num1 = numStack.pop();
						int num2 = numStack.pop();
						numStack.push(num1 / num2);}
						catch(Exception e) {
							System.out.println("Cannot divide by 0 " + e);
						}
						
					}
						
				} else if (element.equals("%")) {
					if (numStack.size() < 2) {
						System.out.println("Missing operands");
					} else {
						// Utilize a try-catch block to handle the modulus by 0 exception
						try {
						int num1 = numStack.pop();
						int num2 = numStack.pop();
						numStack.push(num1 % num2);}
						catch(Exception e) {
							System.out.println("Cannot do modulus of 0 " + e);
						}
						
					}
				}

				// Print the entire stack's content if the user enters "<<"
				else if (element.equals("<<")) {
					System.out.println(numStack);
				}

				// Pop the top element off the stack and print it if the user enters "^"
				else if (element.equals("^")) {
					result = numStack.pop();
					System.out.println(result);
				}

				// Terminate program if the user enters "\" in the expression
				else if (element.equals("\\")) {
					if (!numStack.empty()) {
						System.out.println("Result: " + numStack.pop());
						break;
					} else {
						System.out.println("Result: " + result);
					}
				}

				else {
					System.out.println("Invalid input");
				}

			}

			// Allow the user to input more than one expression if they would like
			System.out.print("Calculate again? (yes/no): ");
			again = sc.nextLine();

		}

		// Loop through the program as long as the user would like to continue
		while (again.equals("yes"));

		if (again.equals("no")) {
			System.out.println("Thanks for using expression calculator!");
		}

		sc.close();

	}

}